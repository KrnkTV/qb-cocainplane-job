fx_version 'bodacious'

games { 'gta5' }


author 'Erratic'


client_scripts {
    'config.lua',
    'client/main.lua'
}

server_scripts {
    'config.lua',
    'server/main.lua'
}




